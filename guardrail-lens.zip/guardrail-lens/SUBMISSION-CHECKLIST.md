# Guardrail Lens submission checklist

## OpenSearch contest requirements

- [ ] Legal U.S. resident, age 18+, confirmed.
- [ ] Submission identity confirmed: exact legal name, email, and GitHub account must match the
      entrant's truthful identity.
- [ ] Solo or team of no more than two, confirmed.
- [ ] Skill focuses on OpenSearch search, observability, log analytics, or security analytics.
- [ ] Production-ready code included.
- [ ] README explains installation, input mapping, output, portability, and limitations.
- [ ] Five-minute demo video recorded with use case, solution, and measurable impact.
- [ ] No proprietary dependency required.
- [ ] Works with self-managed, Docker, or Kubernetes OpenSearch distributions after adapter wiring.
- [ ] Submission submitted by **August 17, 2026 at 11:59 p.m. PST**.
- [ ] Official rules and promotion documentation reviewed before final submission.

## Current local status

- [x] Read-only skill definition
- [x] Dependency-free analyzer
- [x] Deterministic sample fixture
- [x] Demo script
- [x] Evaluation notes
- [x] Submission copy
- [x] OpenSearch read-only index adapter field mapping and query template
- [ ] Demo video
- [ ] Eligibility and identity confirmation
- [ ] External submission
