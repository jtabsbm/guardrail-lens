# Guardrail Lens: five-minute demo script

The OpenSearch hackathon asks for a five-minute demo focused on use case, solution, and measurable
impact. This script keeps the demo read-only and deterministic.

## 0:00–0:30 — Problem

“AI-agent security events mix authorization, tools, tenants, traces, and reliability signals. A
team needs a quick answer to three questions: what was unblocked, what evidence supports it, and
what should happen next?”

## 0:30–1:15 — Skill and safety

Show `SKILL.md`. Explain that Guardrail Lens is read-only by default, accepts an export or an
authorized index, redacts sensitive values, and does not scan or modify a live system.

## 1:15–2:00 — Input

Open `sample-security-events.json`. Point out `asset`, `category`, `severity`, `blocked`, `tenant`,
and `evidence`. Explain that the same shape can be mapped from OpenSearch observability documents.

## 2:00–3:15 — Run

Run:

```bash
node scripts/analyze-export.mjs sample-security-events.json
```

Call out the unblocked high/critical count, authorization gap, sensitive-data signal, tool surface,
and prevention rate. Emphasize that every finding includes evidence and a defensive next step.

If a visual walkthrough is easier, open `demo-report.html` after running the command. It mirrors the
same deterministic fixture and keeps the safety boundary visible on screen.

Optional adapter proof:

```bash
node scripts/analyze-opensearch-export.mjs sample-opensearch-export.json
```

Call out that `os-001` and `os-002` remain available as evidence IDs without connecting to a live
cluster.

## 3:15–4:00 — Deterministic evaluation

Run:

```bash
node scripts/evaluate.mjs
```

Show that the critical exposure, blocked benign path, and unblocked authorization cases all pass.

## 4:00–5:00 — OpenSearch path

Explain the next adapter step: issue a read-only query against an authorized index, map documents
to the event fields, and add links to matching event IDs. Keep writes, live probes, credential use,
and exploit instructions out of the skill.
