# Read-only OpenSearch adapter

Guardrail Lens accepts exported JSON first so the demo is deterministic. For an authorized
OpenSearch deployment, use a read-only query and map the returned documents to the event shape:

```json
{
  "timestamp": "@timestamp",
  "asset": "asset",
  "category": "security.category",
  "severity": "event.severity",
  "blocked": "security.blocked",
  "actor": "user.name",
  "tenant": "tenant.id",
  "action": "event.action",
  "evidence": "message"
}
```

Example read-only query body:

```json
{
  "size": 200,
  "_source": [
    "@timestamp",
    "asset",
    "security.category",
    "event.severity",
    "security.blocked",
    "user.name",
    "tenant.id",
    "event.action",
    "message"
  ],
  "query": {
    "bool": {
      "filter": [
        { "range": { "@timestamp": { "gte": "now-24h" } } },
        {
          "terms": {
            "security.category": [
              "authorization",
              "access-control",
              "tenant-isolation",
              "secret",
              "credential",
              "data-exposure",
              "tool-execution",
              "agent-tool",
              "ssrf"
            ]
          }
        }
      ]
    }
  },
  "sort": [{ "@timestamp": "desc" }]
}
```

Safety requirements:

- Use an index alias and credentials with read-only permissions.
- Confirm the operator owns or is authorized to inspect the index.
- Redact secrets and personal data before exporting or sharing results.
- Do not enable writes, scripted updates, or live probes for the initial demo.
- Preserve event IDs and timestamps so every finding can link to source evidence.
