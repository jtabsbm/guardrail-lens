---
name: guardrail-lens
description: Analyze exported OpenSearch security and agent events to identify unblocked high-impact activity, authorization gaps, sensitive-data exposure, and tool-execution risk with evidence-linked next steps.
metadata:
  version: 0.2.0
  compatibility: OpenSearch Agent Skills
---

# Guardrail Lens

Use this skill for defensive triage of OpenSearch security, observability, and AI-agent events.
The skill is read-only by default and does not scan, probe, modify, or exfiltrate data.

## Inputs

Ask for one of:

1. An exported JSON file containing an `events` array.
2. An authorized OpenSearch index alias plus a time range and field mapping.

Each event should expose these fields when available:

`timestamp`, `asset`, `category`, `severity`, `blocked`, `actor`, `tenant`, `action`, and `evidence`.

If fields are missing, report which fields were unavailable rather than inventing values.

## Workflow

1. Confirm the user owns or is authorized to inspect the supplied index or export.
2. Prefer a local export or a read-only query.
3. Normalize the event fields into the Guardrail Lens shape.
4. Run `scripts/analyze-export.mjs <path-to-export.json>`.
5. Return:
   - scope: event count, asset count, and categories
   - metrics: high/critical counts, unblocked high/critical counts, blocked rate, and repeated assets
   - findings with evidence and a concrete next step
   - caveat that this is triage, not proof of exploitability
6. If a live OpenSearch integration is available, link each finding to the matching event IDs.
7. Never execute write actions, credential changes, exploit steps, or destructive tests.

## Finding rules

- Treat unblocked high or critical events as urgent signals.
- Treat unblocked authorization, access-control, or tenant-isolation events as an authorization gap.
- Treat `secret`, `credential`, and `data-exposure` categories as sensitive-data signals.
- Treat `tool-execution`, `agent-tool`, and `ssrf` categories as agent-tool surface signals.
- Distinguish blocked attempts from successful or unblocked activity.
- Redact secrets and personal data from all output.

## Safe response pattern

State what the data shows, cite the event IDs or evidence fields, and recommend a defensive next
step. If the result indicates real exposure, tell the user to preserve minimum evidence, rotate
affected credentials, and route the issue to the incident owner. Do not provide an exploit recipe.

## Local demo

```bash
node scripts/analyze-export.mjs sample-security-events.json
node scripts/evaluate.mjs
```

The package includes no network calls and no paid dependencies.

For an exported OpenSearch response, use
`scripts/analyze-opensearch-export.mjs <export.json>`. It preserves hit IDs as `event_ids` in
findings without contacting a live cluster.
