#!/usr/bin/env node

import fs from "node:fs";
import process from "node:process";
import { analyze } from "./security-signal-analyzer.mjs";

const cases = JSON.parse(
  fs.readFileSync(new URL("../evaluation-cases.json", import.meta.url), "utf8")
);
let failures = 0;

for (const testCase of cases) {
  const report = analyze(testCase.input);
  const signals = new Set(report.findings.map((finding) => finding.signal));
  const missing = testCase.expect.filter((signal) => !signals.has(signal));
  if (missing.length) {
    failures += 1;
    console.error(`FAIL ${testCase.name}: missing ${missing.join(", ")}`);
  } else {
    console.log(`PASS ${testCase.name}`);
  }
}

if (failures) {
  console.error(`${failures} evaluation case(s) failed`);
  process.exitCode = 1;
} else {
  console.log(`\n${cases.length} evaluation cases passed`);
}
