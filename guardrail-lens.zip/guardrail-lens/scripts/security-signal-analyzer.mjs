#!/usr/bin/env node

/**
 * Security Signal Analyzer
 *
 * Defensive, offline triage for exported security/agent events.
 * It reads JSON, performs no network calls, and never probes a target.
 *
 * Input shape:
 * {
 *   "events": [
 *     {
 *       "timestamp": "2026-08-14T10:00:00Z",
 *       "asset": "agent-api",
 *       "category": "authorization",
 *       "severity": "high",
 *       "blocked": false,
 *       "actor": "service-account",
 *       "tenant": "acme",
 *       "action": "tool.invoke",
 *       "evidence": "policy mismatch"
 *     }
 *   ]
 * }
 */

import fs from "node:fs";
import process from "node:process";

const severityRank = { info: 0, low: 1, medium: 2, high: 3, critical: 4 };

function round(value, digits = 3) {
  return Number(Number(value || 0).toFixed(digits));
}

function parseBoolean(value) {
  if (value === true || value === 1) return true;
  if (typeof value === "string") {
    return ["true", "1", "yes", "blocked", "deny", "denied"].includes(value.trim().toLowerCase());
  }
  return false;
}

function loadInput(path) {
  let raw;
  try {
    raw = fs.readFileSync(path, "utf8");
  } catch (error) {
    throw new Error(`Could not read ${path}: ${error.message}`);
  }
  let parsed;
  try {
    parsed = JSON.parse(raw);
  } catch (error) {
    throw new Error(`Invalid JSON: ${error.message}`);
  }
  if (!parsed || !Array.isArray(parsed.events) || parsed.events.length === 0) {
    throw new Error("events must be a non-empty array");
  }
  return parsed;
}

function normalize(event, index) {
  const severity = String(event.severity || "info").toLowerCase();
  return {
    id: event.id || `event-${index + 1}`,
    timestamp: event.timestamp || null,
    asset: String(event.asset || "unknown"),
    category: String(event.category || "unknown").toLowerCase(),
    severity: severityRank[severity] === undefined ? "info" : severity,
    blocked: parseBoolean(event.blocked),
    actor: String(event.actor || "unknown"),
    tenant: String(event.tenant || "unknown"),
    action: String(event.action || "unknown"),
    evidence: String(event.evidence || ""),
    source_url: event.source_url ? String(event.source_url) : null,
  };
}

function analyze(input) {
  const events = input.events.map(normalize);
  const highImpact = events.filter((event) => severityRank[event.severity] >= severityRank.high);
  const unblockedHighImpact = highImpact.filter((event) => !event.blocked);
  const authzFailures = events.filter(
    (event) =>
      ["authorization", "access-control", "tenant-isolation"].includes(event.category) &&
      !event.blocked
  );
  const secretSignals = events.filter(
    (event) => ["secret", "credential", "data-exposure"].includes(event.category)
  );
  const toolSignals = events.filter(
    (event) => ["tool-execution", "agent-tool", "ssrf"].includes(event.category)
  );
  const assets = new Set(events.map((event) => event.asset));
  const blockedRate = events.filter((event) => event.blocked).length / events.length;
  const criticalCount = events.filter((event) => event.severity === "critical").length;

  const byAsset = new Map();
  for (const event of events) {
    byAsset.set(event.asset, (byAsset.get(event.asset) || 0) + 1);
  }
  const repeatedAssets = [...byAsset.entries()]
    .filter(([, count]) => count >= 2)
    .sort((a, b) => b[1] - a[1])
    .map(([asset, count]) => ({ asset, events: count }));

  const findings = [];
  if (unblockedHighImpact.length) {
    findings.push({
      severity: criticalCount ? "critical" : "high",
      signal: "unblocked_high_impact",
      evidence: `${unblockedHighImpact.length} high/critical event(s) were not blocked`,
      event_ids: unblockedHighImpact.map((event) => event.id),
      next_step: "Preserve minimal evidence, confirm authorization, and route the event to the incident owner.",
    });
  }
  if (authzFailures.length) {
    findings.push({
      severity: "high",
      signal: "authorization_gap",
      evidence: `${authzFailures.length} unblocked authorization or tenant-isolation event(s)`,
      event_ids: authzFailures.map((event) => event.id),
      next_step: "Reproduce only in a test fixture, then add a deny-path regression test and review policy scope.",
    });
  }
  if (secretSignals.length) {
    findings.push({
      severity: "high",
      signal: "secret_or_data_exposure_signal",
      evidence: `${secretSignals.length} event(s) indicate credentials or sensitive-data exposure`,
      event_ids: secretSignals.map((event) => event.id),
      next_step: "Redact evidence, rotate exposed material if real, and verify logging does not retain secrets.",
    });
  }
  if (toolSignals.length) {
    findings.push({
      severity: "medium",
      signal: "agent_tool_surface",
      evidence: `${toolSignals.length} event(s) involve tools, SSRF, or agent execution`,
      event_ids: toolSignals.map((event) => event.id),
      next_step: "Check allowlists, destination validation, identity propagation, and least-privilege tool tokens.",
    });
  }
  if (blockedRate < 0.5 && events.length >= 4) {
    findings.push({
      severity: "medium",
      signal: "low_prevention_rate",
      evidence: `blocked rate is ${round(blockedRate * 100, 1)}%`,
      event_ids: events.filter((event) => !event.blocked).map((event) => event.id),
      next_step: "Separate detection from prevention and measure which policies fail open.",
    });
  }
  if (repeatedAssets.length) {
    findings.push({
      severity: "low",
      signal: "repeated_asset_activity",
      evidence: `${repeatedAssets[0].asset} has ${repeatedAssets[0].events} recorded events`,
      event_ids: events.filter((event) => event.asset === repeatedAssets[0].asset).map((event) => event.id),
      next_step: "Group by actor, tenant, and action to distinguish a noisy control from a concentrated incident.",
    });
  }
  if (!findings.length) {
    findings.push({
      severity: "info",
      signal: "no_obvious_control_gap",
      evidence: "the supplied sample is inside the analyzer's conservative guardrails",
      event_ids: events.map((event) => event.id),
      next_step: "Add request IDs, policy versions, and quality labels for a deeper review.",
    });
  }

  return {
    scope: {
      events: events.length,
      assets: assets.size,
      categories: [...new Set(events.map((event) => event.category))].sort(),
    },
    evidence_refs: events.map((event) => ({
      id: event.id,
      timestamp: event.timestamp,
      asset: event.asset,
      category: event.category,
      severity: event.severity,
      blocked: event.blocked,
      action: event.action,
      source_url: event.source_url,
    })),
    metrics: {
      high_or_critical_events: highImpact.length,
      unblocked_high_or_critical_events: unblockedHighImpact.length,
      critical_events: criticalCount,
      authorization_gap_events: authzFailures.length,
      secret_or_data_exposure_events: secretSignals.length,
      agent_tool_surface_events: toolSignals.length,
      blocked_rate: round(blockedRate, 4),
      repeated_assets: repeatedAssets,
    },
    findings,
    caveat:
      "This is offline triage, not a penetration test or proof of exploitability. Validate every conclusion against authorized scope, preserved evidence, and an incident owner.",
  };
}

export { analyze, loadInput };

function main() {
  const file = process.argv[2];
  if (!file) {
    console.error("Usage: node security-signal-analyzer.mjs <events.json> [--json]");
    process.exitCode = 2;
    return;
  }

  try {
    const report = analyze(loadInput(file));
    if (process.argv.includes("--json")) {
      console.log(JSON.stringify(report, null, 2));
    } else {
      console.log("INFERENCE CLINIC / SECURITY SIGNAL REPORT");
      console.log("------------------------------------------");
      console.log(`Events: ${report.scope.events}`);
      console.log(`Assets: ${report.scope.assets}`);
      console.log(`High/critical: ${report.metrics.high_or_critical_events}`);
      console.log(`Unblocked high/critical: ${report.metrics.unblocked_high_or_critical_events}`);
      console.log(`Blocked rate: ${(report.metrics.blocked_rate * 100).toFixed(1)}%`);
      console.log("\nFindings:");
      for (const finding of report.findings) {
        console.log(`- [${finding.severity}] ${finding.signal}: ${finding.evidence}`);
        console.log(`  Next: ${finding.next_step}`);
      }
      console.log(`\nCaveat: ${report.caveat}`);
    }
  } catch (error) {
    console.error(error.message);
    process.exitCode = 1;
  }
}

if (process.argv[1] && import.meta.url === new URL(process.argv[1], "file:").href) {
  main();
}
