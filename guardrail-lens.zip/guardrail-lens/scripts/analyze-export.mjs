#!/usr/bin/env node

import process from "node:process";
import { analyze, loadInput } from "./security-signal-analyzer.mjs";

const file = process.argv[2];
if (!file) {
  console.error("Usage: node scripts/analyze-export.mjs <events.json> [--json]");
  process.exitCode = 2;
} else {
  try {
    const report = analyze(loadInput(file));
    if (process.argv.includes("--json")) {
      console.log(JSON.stringify(report, null, 2));
    } else {
      console.log("GUARDRAIL LENS / OPENSEARCH SECURITY TRIAGE");
      console.log("--------------------------------------------");
      console.log(`Events: ${report.scope.events}`);
      console.log(`Assets: ${report.scope.assets}`);
      console.log(`High/critical: ${report.metrics.high_or_critical_events}`);
      console.log(`Unblocked high/critical: ${report.metrics.unblocked_high_or_critical_events}`);
      console.log(`Blocked rate: ${(report.metrics.blocked_rate * 100).toFixed(1)}%`);
      console.log("\nFindings:");
      for (const finding of report.findings) {
        console.log(`- [${finding.severity}] ${finding.signal}: ${finding.evidence}`);
        console.log(`  Next: ${finding.next_step}`);
      }
      console.log(`\nCaveat: ${report.caveat}`);
    }
  } catch (error) {
    console.error(error.message);
    process.exitCode = 1;
  }
}
