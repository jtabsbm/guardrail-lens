#!/usr/bin/env node

/**
 * Offline adapter for an authorized, read-only OpenSearch export.
 *
 * Accepted input:
 * - OpenSearch response JSON with hits.hits[]._id and _source
 * - { "documents": [{ "_id": "...", "_source": {...} }] }
 * - A plain { "events": [...] } file, passed through unchanged
 *
 * No network calls are made. The caller is responsible for authorization and redaction.
 */

import fs from "node:fs";
import process from "node:process";
import { analyze } from "./security-signal-analyzer.mjs";

const inputPath = process.argv[2];
if (!inputPath) {
  console.error("Usage: node scripts/analyze-opensearch-export.mjs <export.json> [--json]");
  process.exitCode = 2;
}

const mapping = {
  timestamp: "@timestamp",
  asset: "asset",
  category: "security.category",
  severity: "event.severity",
  blocked: "security.blocked",
  actor: "user.name",
  tenant: "tenant.id",
  action: "event.action",
  evidence: "message",
};

function getPath(value, path) {
  return path.split(".").reduce((current, key) => current?.[key], value);
}

function readInput(path) {
  try {
    return JSON.parse(fs.readFileSync(path, "utf8"));
  } catch (error) {
    throw new Error(`Could not read or parse ${path}: ${error.message}`);
  }
}

function hitsFrom(input) {
  if (Array.isArray(input?.events)) return input.events;
  if (Array.isArray(input?.hits?.hits)) return input.hits.hits;
  if (Array.isArray(input?.documents)) return input.documents;
  throw new Error("Expected events[], hits.hits[], or documents[]");
}

function mapHit(hit, index) {
  const source = hit?._source || hit?.source || hit;
  const event = {};
  for (const [field, path] of Object.entries(mapping)) {
    const value = getPath(source, path);
    if (value !== undefined && value !== null) event[field] = value;
  }
  event.id = hit?._id || source?.id || `export-event-${index + 1}`;
  if (hit?._index) event.source_url = `opensearch://${hit._index}/${event.id}`;
  return event;
}

try {
  const input = readInput(inputPath);
  const report = analyze({ events: hitsFrom(input).map(mapHit) });
  if (process.argv.includes("--json")) {
    console.log(JSON.stringify(report, null, 2));
  } else {
    console.log("GUARDRAIL LENS / OPENSEARCH EXPORT TRIAGE");
    console.log("-------------------------------------------");
    console.log(`Events: ${report.scope.events}`);
    console.log(`Assets: ${report.scope.assets}`);
    console.log(`High/critical: ${report.metrics.high_or_critical_events}`);
    console.log(`Unblocked high/critical: ${report.metrics.unblocked_high_or_critical_events}`);
    console.log(`Blocked rate: ${(report.metrics.blocked_rate * 100).toFixed(1)}%`);
    console.log("\nFindings:");
    for (const finding of report.findings) {
      console.log(`- [${finding.severity}] ${finding.signal}: ${finding.evidence}`);
      console.log(`  Evidence IDs: ${finding.event_ids.join(", ")}`);
      console.log(`  Next: ${finding.next_step}`);
    }
    console.log(`\nCaveat: ${report.caveat}`);
  }
} catch (error) {
  console.error(error.message);
  process.exitCode = 1;
}
